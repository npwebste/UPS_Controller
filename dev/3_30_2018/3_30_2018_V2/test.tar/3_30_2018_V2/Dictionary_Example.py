reg = {
    "WriteFunc":{
        "Write1":113,
	"Write2":115
        },
    "ReadFunc":{
        "Read1":114
        }
    }

	
	reg.get("WriteFunc",{}).get("Write1")